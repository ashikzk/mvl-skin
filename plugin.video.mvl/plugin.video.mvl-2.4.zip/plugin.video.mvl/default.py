from xbmcswift2 import Plugin, xbmcgui, xbmc, xbmcaddon, xbmcplugin, actions
import urllib2
import time
import simplejson as json
import urllib
import urllib2
import urlresolver
import xbmcvfs
import xbmcaddon
import xbmcplugin
from t0mm0.common.addon import Addon
import re
import sys
import os
import resources.htmlcleaner
import traceback

_MVL = Addon('plugin.video.mvl', sys.argv)
plugin = Plugin()
pluginhandle = int(sys.argv[1])
usrsettings = xbmcaddon.Addon(id='plugin.video.mvl')
page_limit = usrsettings.getSetting('page_limit_xbmc')
authentication = plugin.get_storage('authentication', TTL=1)
authentication['logged_in'] = 'false'
username = usrsettings.getSetting('username_xbmc')
activation_key = usrsettings.getSetting('activationkey_xbmc')
usrsettings.setSetting(id='mac_address', value=usrsettings.getSetting('mac_address'))
THEME_PATH = os.path.join(_MVL.get_path(), 'art')

# server_url = 'http://staging.redbuffer.net/xbmc'
# server_url = 'http://localhost/xbmc'
server_url = 'http://config.myvideolibrary.com'

try:
    import StorageServer
except:
    import storageserverdummy as StorageServer
cache = StorageServer.StorageServer("mvl_storage_data", 24) # (Your plugin name, Cache time in hours)

try:
    from sqlite3 import dbapi2 as orm
    plugin.log.info('Loading sqlite3 as DB engine')
except:
    from pysqlite2 import dbapi2 as orm
    plugin.log.info('pysqlite2 as DB engine')
DB = 'sqlite'
__translated__ = xbmc.translatePath("special://database")
DB_DIR = os.path.join(__translated__, 'myvideolibrary.db')
plugin.log.info('DB_DIR: '+DB_DIR)

@plugin.route('/')
def index():
    try:
        #creating the database if not exists
        init_database()
        #creating a context menu
        #url used to get main categories from server
        url = server_url+"/api/index.php/api/categories_api/getCategories?parent_id=0&limit={0}&page=1".format(page_limit)
        plugin.log.info(url)
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        f = opener.open(req)
        #reading content fetched from the url
        content = f.read()
        #converting to json object
        jsonObj = json.loads(content)
        items = []

        #creating items from json object
        for categories in jsonObj:
                items += [{
                    'label': '{0}'.format(categories['title']),
                    'path': plugin.url_for('get_categories', id=categories['id'], page=0),
                    'is_playable': False,
                    'thumbnail': art('{0}.png'.format(categories['title'].lower())),
                }]
        return items
    except IOError:
        xbmc.executebuiltin('Notification(Unreachable Host,Could not connect to server,5000,/error.png)')

def art(name):

    plugin.log.info('plugin-name')
    plugin.log.info(name)
    art_img = os.path.join(THEME_PATH, name)
    return art_img

def get_mac_address():
    try:
        local_mac_address = xbmc.getInfoLabel('Network.MacAddress')
        if local_mac_address == 'Busy':
                time.sleep(1)
                get_mac_address()
        else:
            return local_mac_address
    except IOError:
        xbmc.executebuiltin('Notification(Mac Address Not Available,MVL Could not get the MAC Address,5000,/script.hellow.world.png)')

# xbmc.executebuiltin('Notification(MAC_Flag Check1,{0},2000)'.format(cache.get("mac_address_flag")))
# xbmc.executebuiltin('Notification(MAC_Address Check1,{0},2000)'.format(usrsettings.getSetting('mac_address')))

if cache.get("mac_address_flag") == 'None' or cache.get("mac_address_flag") == '':
    cache.set("mac_address_flag", "false")

if usrsettings.getSetting('mac_address') == 'None' or usrsettings.getSetting('mac_address') == '':
    #xbmc.executebuiltin('Notification(MAC_Address Check2,{0},2000)'.format(usrsettings.getSetting('mac_address')))
    plugin.log.info(get_mac_address())
    usrsettings.setSetting(id='mac_address', value='{0}'.format(get_mac_address()))

@plugin.route('/categories/<id>/<page>')
def get_categories(id, page):
    import resources.htmlcleaner
    
    try:
        
        parent_id = id
        main_category_check = False
        top_level_parent = 0
        xbmcplugin.setContent(pluginhandle, 'Movies')
        plugin.log.info(id)
        plugin.log.info(page)
        plugin.log.info(page_limit)
        url = server_url+"/api/index.php/api/categories_api/getCategories?parent_id={0}&page={1}&limit={2}".format(id,page,page_limit)
        plugin.log.info(url)
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        f = opener.open(req)
        content = f.read()
        items = []
        if content:
            jsonObj = json.loads(content)
            for categories in jsonObj:
                
                
                try:    # The last item of Json only contains the one element in array with key as "ID" so causing the issue
                    
                    plugin.log.info('{0}'.format(categories['is_playable']))
                    if categories['top_level_parent'] == categories['parent_id']:
                        main_category_check = True
                    
                except:
                    pass
                    
                #categories['id'] is -1 when more categories are present and next page option should be displayed
                if categories['id'] == -1:
                    items += [{
                        'label': 'Next >>',
                        'path': plugin.url_for('get_categories', id=parent_id, page=(int(page)+1)),
                        'is_playable': False,
                        'thumbnail': art('next.png')
                    }]
                #categories['is_playable'] is False for all categories and True for all video Items
                elif categories['is_playable'] == 'False':
                    items += [{
                        'label': '{0}'.format(categories['title']),
                        'path': plugin.url_for('get_categories', id=categories['id'], page=0),
                        'is_playable': False,
                        'thumbnail': art('{0}.png'.format(categories['title'].lower())),
                        'context_menu': [(
                            'Add to Favourites', 'XBMC.RunPlugin(%s)' % plugin.url_for('save_favourite', id=categories['id'], title=categories['title'], thumbnail="None", isplayable="False", category=categories['top_level_parent'])
                        )],
                        'replace_context_menu': True
                    }]
                    plugin.log.info(art('{0}.png'.format(categories['title'].lower())))

                #inorder for the information to be displayed properly, corresponding labels should be added in skin
                elif categories['is_playable'] == 'True':
                    if categories['source'] == '1':
                        thumbnail_url = categories['image_name']
                    else:
                        thumbnail_url = server_url+'/wp-content/themes/twentytwelve/images/{0}'.format(categories['video_id']+categories['image_name'])
                    items += [{
                        'thumbnail': thumbnail_url,
                        'properties': {
                            'fanart_image': thumbnail_url,
                        },
                        'label': '{0}'.format(categories['title'].encode('utf-8')),
                        'info': {
                            'title': categories['title'].encode('utf-8'),
                            'rating': categories['rating'],
                            'comment': categories['synopsis'].encode('utf-8'),
                            'Director': categories['director'].encode('utf-8'),
                            'Producer': categories['producer'],
                            'Writer': categories['writer'],
							'plot': categories['synopsis'].encode('utf-8'),
							'genre': categories['sub_categories_names'],
                            'cast': categories['actors'].encode('utf-8'),
                            'year': categories['release_date']
                        },
                        'path': plugin.url_for('get_videos', id=categories['video_id'], thumbnail=thumbnail_url),
                        'is_playable': False,
                        'context_menu': [(
                            'Add to Favourites', 'XBMC.RunPlugin(%s)' % plugin.url_for('save_favourite', id=categories['video_id'], title=categories['title'].encode('utf-8'), thumbnail=thumbnail_url, isplayable="True", category=categories['top_level_parent'])
                        )],
                        'replace_context_menu': True
                    }]
            if main_category_check == True:
                #adding search option
                items += [{
                            'label': 'Search',
                            'path': plugin.url_for('search', category=parent_id),
                            'thumbnail' : art('search.png'),
                            'is_playable': False,
                        }]
                #adding A-Z listing option
                items += [{
                            'label': 'A-Z Listings',
                            'path': plugin.url_for('azlisting', category=parent_id),
                            'thumbnail' : art('A-Z.png'),
                            'is_playable': False,
                        }]
                #adding Most Popular option
                items += [{
                            'label': 'Most Popular',
                            'path': plugin.url_for('mostpopular', page=0, category=parent_id),
                            'thumbnail' : art('pop.png'),
                            'is_playable': False,
                        }]
                #adding Favourites option
                items += [{
                            'label': 'Favourites',
                            'path': plugin.url_for('get_favourites', category=parent_id),
                            'thumbnail' : art('fav.png'),
                            'is_playable': False,
                        }]
        #plugin.log.info(items)
        return items
    except IOError:
        xbmc.executebuiltin('Notification(Unreachable Host,Could not connect to server,5000,/script.hellow.world.png)')
    except Exception, e:
        xbmc.executebuiltin('Notification(Unreachable Host,Could not connect to server,5000,/script.hellow.world.png)')
        plugin.log.info(e)
        traceback.print_exc()

@plugin.route('/get_videos/<id>/<thumbnail>/')
def get_videos(id, thumbnail):
    try:
        url = server_url+"/api/index.php/api/categories_api/getVideoUrls?video_id={0}".format(id)
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        f = opener.open(req)
        content = f.read()
        jsonObj = json.loads(content)

        url = server_url+"/api/index.php/api/categories_api/getVideoTitle?video_id={0}".format(id)
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        f = opener.open(req)
        content = f.read()
        count = 0
        items = []
        plugin.log.info(jsonObj)

        for urls in jsonObj:
                count += 1
                items += [{
                    'label': '{0} Source {1}'.format(content, count),
                    'thumbnail': thumbnail,
                    'path': plugin.url_for('play_video', url=urls['URL']),
                    'is_playable': True,
                }]

        return items
    except IOError:
        xbmc.executebuiltin('Notification(Unreachable Host,Could not connect to server,5000,/error.png)')

@plugin.route('/play_video/<url>')
def play_video(url):
    #if login is successful then selected item will be resolved using urlresolver and played
    if login_check():
        hostedurl = urlresolver.HostedMediaFile(url).resolve()
        plugin.set_resolved_url(hostedurl)
    else:
        pass

def login_check():
    try:
        url = server_url+"/api/index.php/api/authentication_api/authenticate_user"
        #urlencode is used to create a json object which will be sent to server in POST
        data = urllib.urlencode({'username': '{0}'.format(username), 'activation_key': '{0}'.format(activation_key), 'mac_address_flag':cache.get("mac_address_flag"), 'mac_address': '{0}'.format(usrsettings.getSetting('mac_address'))})
        req = urllib2.Request(url, data)
        plugin.log.info(url)
        plugin.log.info(data)
        opener = urllib2.build_opener()
        f = opener.open(req)
        #reading content fetched from the url
        content = f.read()

        #converting to json object
        plugin.log.info("Debug_Content: " + content)
        myObj = json.loads(content)
        plugin.log.info(myObj)

        #creating items from json object
        for row in myObj:
            if row['status'] == 1 :
                return True
            else :
                xbmc.executebuiltin('Notification(License Limit Reached,'+row['message']+')')
                return False
    except IOError:
        xbmc.executebuiltin('Notification(Unreachable Host,Could not connect to server,5000,/error.png)')
    pass

@plugin.route('/search/<category>/')
def search(category):
    try:
        search_string = plugin.keyboard(heading=('search'))
        url = server_url+"/api/index.php/api/categories_api/searchVideos"
        plugin.log.info(url)
        data = urllib.urlencode({'keywords': '{0}'.format(search_string), 'category': '{0}'.format(category)})
        req = urllib2.Request(url, data)
        f = urllib2.urlopen(req)
        response = f.read()
        if response == '0':
            xbmc.executebuiltin('Notification(Sorry,No Videos Found Matching Your Query,5000,/error.png)')
        else:
            jsonObj = json.loads(response)
            items = []
            for categories in jsonObj:
                if categories['is_playable'] == 'False':
                    items += [{
                        'label': '{0}'.format(categories['title']),
                        'path': plugin.url_for('get_categories', id=categories['id'], page=0),
                        'is_playable': False,
                        'thumbnail': art('{0}.png'.format(categories['title'].lower())),
                        'context_menu': [(
                            'Add to Favourites', 'XBMC.RunPlugin(%s)' % plugin.url_for('save_favourite', id=categories['id'], title=categories['title'], thumbnail="None", isplayable="False", category=category)
                        )],
                        'replace_context_menu': True
                    }]
                elif categories['is_playable'] == 'True':
                    items += [{
                        'label': '{0}'.format(categories['title']),
                        'path': plugin.url_for('get_videos', id=categories['video_id'], thumbnail="None"),
                        'is_playable': False,
                        'thumbnail' : categories['thumbnail'],
                        'context_menu': [(
                            'Add to Favourites', 'XBMC.RunPlugin(%s)' % plugin.url_for('save_favourite', id=categories['id'], title=categories['title'], thumbnail="None", isplayable="True", category=category)
                        )],
                        'replace_context_menu': True
                    }]
            return items
    except IOError:
        xbmc.executebuiltin('Notification(Unreachable Host,Could not connect to server,5000,/script.hellow.world.png)')


@plugin.route('/azlisting/<category>/')
def azlisting(category):
    Indices = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
    items = [{
                'label': '#',
                'path': plugin.url_for('get_azlist', key='%23', page=0, category=category),
                'is_playable': False,
            }]
    for index in Indices:
        items += [{
                'label': '{0}'.format(index),
                'path': plugin.url_for('get_azlist', key=index, page=0, category=category),
                'is_playable': False,
            }]
    return items

@plugin.route('/get_azlist/<key>/<page>/<category>/')
def get_azlist(key, page, category):
    try:
        url = server_url+"/api/index.php/api/categories_api/getAZList?key={0}&limit={1}&page={2}&category={3}".format(key, page_limit, page, category)
        plugin.log.info(url)
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        f = opener.open(req)
        content = f.read()
        if content != '0':
            jsonObj = json.loads(content)
            items = []
            for results in jsonObj:
                if results['id'] == -1:
                    items += [{
                        'label': 'Next >>',
                        'path': plugin.url_for('get_azlist', key=key, page=(int(page)+1), category=category),
                        'thumbnail': art('next.png'),
                        'is_playable': False,
                    }]
                elif results['is_playable'] == 'False':
                    items += [{
                        'label': '{0}'.format(results['title']),
                        'path': plugin.url_for('get_categories', id=results['id'], page=0),
                        'is_playable': False,
                        'thumbnail': art('{0}.png'.format(results['title'].lower())),
                        'context_menu': [(
                            'Add to Favourites', 'XBMC.RunPlugin(%s)' % plugin.url_for('save_favourite', id=results['id'], title=results['title'], thumbnail="None", isplayable="False", category=category)
                        )],
                        'replace_context_menu': True
                    }]
                elif results['is_playable'] == 'True':
                    items += [{
                        'label': '{0}'.format(results['title'].encode('utf-8')),
                        'path': plugin.url_for('get_videos', id=results['video_id'], thumbnail=results['thumbnail']),
                        'thumbnail' : results['thumbnail'],
                        'is_playable': False,
                        'context_menu': [(
                            'Add to Favourites', 'XBMC.RunPlugin(%s)' % plugin.url_for('save_favourite', id=results['video_id'], title=results['title'], thumbnail="None", isplayable="True", category=category)
                        )],
                        'replace_context_menu': True
                    }]
            plugin.log.info('itemcheck')
            plugin.log.info(items)
            return items
        else:
            xbmc.executebuiltin('Notification(Sorry,No Videos Available In this Category,5000,/error.png)')
    except IOError:
        xbmc.executebuiltin('Notification(Unreachable Host,Could not connect to server,5000,/script.hellow.world.png)')

@plugin.route('/mostpopular/<page>/<category>/')
def mostpopular(page, category):
    try:
        url = server_url+"/api/index.php/api/categories_api/getMostPopular?limit={0}&page={1}&category={2}".format(page_limit, page, category)
        plugin.log.info(url)
        req = urllib2.Request(url)
        opener = urllib2.build_opener()
        f = opener.open(req)
        content = f.read()
        if content != '0':
            jsonObj = json.loads(content)
            items = []
            for results in jsonObj:
                if results['id'] == -1:
                    items += [{
                        'label': 'Next >>',
                        'path': plugin.url_for('mostpopular', page=(int(page)+1)),
                        'is_playable': False,
                    }]
                else:
                    if results['source'] == '1':
                        thumbnail_url = results['image_name']
                    else:
                        thumbnail_url = server_url+'/wp-content/themes/twentytwelve/images/{0}'.format(results['id']+results['image_name'])
                    items += [{
                        'label': '{0}'.format(results['title']),
                        'thumbnail': thumbnail_url,
                        'path': plugin.url_for('get_videos', id=results['id'], thumbnail=thumbnail_url),
                        'is_playable': False,
                        'context_menu': [(
                            'Add to Favourites', 'XBMC.RunPlugin(%s)' % plugin.url_for('save_favourite', id=results['id'], title=results['title'], thumbnail=thumbnail_url, isplayable="True", category=category)
                        )],
                        'replace_context_menu': True
                    }]
            return items
        else:
            xbmc.executebuiltin('Notification(Sorry,No Videos Available In this Category,5000,/error.png)')
    except IOError:
        xbmc.executebuiltin('Notification(Unreachable Host,Could not connect to server,5000,/script.hellow.world.png)')

def init_database():
    plugin.log.info('Building My Video Library Database')
    if not xbmcvfs.exists(os.path.dirname(DB_DIR)):
        xbmcvfs.mkdirs(os.path.dirname(DB_DIR))
    db = orm.connect(DB_DIR)
    db.execute('CREATE TABLE IF NOT EXISTS favourites (id, title, thumbnail, isplayable, category, PRIMARY KEY (id, title, category))')
    db.commit()
    db.close()

@plugin.route('/save_favourite/<id>/<title>/<thumbnail>/<isplayable>/<category>')
def save_favourite(id, title, thumbnail, isplayable, category):
    plugin.log.info(id)
    plugin.log.info(title)
    plugin.log.info(thumbnail)
    plugin.log.info(isplayable)
    plugin.log.info(category)
    try:
        statement = 'INSERT OR IGNORE INTO favourites (id, title, thumbnail, isplayable, category) VALUES (%s,%s,%s,%s,%s)'
        db = orm.connect(DB_DIR)
        statement = statement.replace("%s", "?")
        cursor = db.cursor()
        cursor.execute(statement, (id, title, thumbnail, isplayable, category))
        db.commit()
        db.close()
    except:
        xbmc.executebuiltin('Notification(Database Error,Please contact software provider,5000,/script.hellow.world.png)')

@plugin.route('/remove_favourite/<id>/<title>/<category>')
def remove_favourite(id, title, category):
    statement = 'DELETE FROM favourites WHERE id=%s AND title=%s AND category=%s'
    db = orm.connect(DB_DIR)
    statement = statement.replace("%s", "?")
    cursor = db.cursor()
    cursor.execute(statement, (id, title, category))
    db.commit()
    db.close()
    return xbmc.executebuiltin("XBMC.Container.Refresh()")

@plugin.route('/get_favourites/<category>/')
def get_favourites(category):
    statement = 'SELECT * FROM favourites WHERE category = "%s"' % category
    plugin.log.info(statement)
    db = orm.connect(DB_DIR)
    cur = db.cursor()
    cur.execute(statement)
    favs = cur.fetchall()
    items = []
    plugin.log.info(favs)
    for row in favs:
        plugin.log.info(row[0])
        if row[3] == 'False':
            items += [{
                'label': '{0}'.format(row[1]),
                'thumbnail': row[2],
                'path': plugin.url_for('get_categories', id=row[0], page=0),
                'is_playable': False,
                'context_menu': [(
                    'Remove from Favourites', 'XBMC.RunPlugin(%s)' % plugin.url_for('remove_favourite', id=row[0], title=row[1], category=row[4])
                )],
                'replace_context_menu': True
            }]
        elif row[3] == 'True':
            items += [{
                'label': '{0}'.format(row[1]),
                'thumbnail': row[2],
                'path': plugin.url_for('get_videos', id=row[0], thumbnail=row[2]),
                'is_playable': False,
                'context_menu': [(
                    'Remove from Favourites', 'XBMC.RunPlugin(%s)' % plugin.url_for('remove_favourite', id=row[0], title=row[1], category=row[4])
                )],
                'replace_context_menu': True
            }]
    db.close()
    return items

if __name__ == '__main__':
    plugin.run()